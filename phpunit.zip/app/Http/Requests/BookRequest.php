<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class BookRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true; // Adjust if you want to restrict access
    }

    public function rules(): array
    {
        return [
            'name' => 'nullable|string|min:3|max:255',
            'category_id' => 'nullable|integer',
            'price' => 'nullable|numeric',
            'publication_date' => 'nullable|date', // or date_format:Y-m-d
            'edition' => 'nullable|string|min:3',
            'author_id' => 'nullable|integer',
            'isbn' => 'nullable|string|min:3|max:255',
            'cover' => 'nullable|string|min:3|max:255', // Or 'image|mimes:jpeg,png|max:2048'
        ];
    }
}
