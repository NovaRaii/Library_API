<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Category;
use App\Http\Requests\CategoryRequest;
/**
 * @api {get} /categories Get All Categories
 * @apiName GetCategories
 * @apiGroup Category
 * @apiVersion 1.0.0
 *
 * @apiSuccess {Object[]} categories List of categories.
 * @apiSuccess {Number} categories.id Category ID.
 * @apiSuccess {String} categories.name Category name.
 * @apiSuccess {String} [categories.description] Category description (optional).
 * @apiSuccess {String} [categories.created_at] Creation timestamp.
 * @apiSuccess {String} [categories.updated_at] Last update timestamp.
 *
 * @apiSuccessExample {json} Success Response:
 * HTTP/1.1 200 OK
 * {
 *   "categories": [
 *     { "id": 1, "name": "Fiction", "description": "Fictional books" },
 *     { "id": 2, "name": "Science", "description": "Science books" }
 *   ]
 * }
 */

/**
 * @api {post} /categories Create Category
 * @apiName CreateCategory
 * @apiGroup Category
 * @apiVersion 1.0.0
 *
 * @apiBody {String} name Category name.
 * @apiBody {String} [description] Category description (optional).
 *
 * @apiSuccess {Object} category Created category object.
 * @apiSuccess {Number} category.id Category ID.
 * @apiSuccess {String} category.name Category name.
 * @apiSuccess {String} [category.description] Category description.
 *
 * @apiSuccessExample {json} Success Response:
 * HTTP/1.1 200 OK
 * {
 *   "category": { "id": 3, "name": "Fantasy", "description": "Fantasy books" }
 * }
 */

/**
 * @api {put} /categories/:id Update Category
 * @apiName UpdateCategory
 * @apiGroup Category
 * @apiVersion 1.0.0
 *
 * @apiParam {Number} id Category’s unique ID.
 * @apiBody {String} [name] Category name.
 * @apiBody {String} [description] Category description.
 *
 * @apiSuccess {Object} category Updated category object.
 * @apiSuccess {Number} category.id Category ID.
 * @apiSuccess {String} category.name Category name.
 * @apiSuccess {String} [category.description] Category description.
 *
 * @apiSuccessExample {json} Success Response:
 * HTTP/1.1 200 OK
 * {
 *   "category": { "id": 3, "name": "Fantasy & Adventure", "description": "Fantasy and adventure books" }
 * }
 */

/**
 * @api {delete} /categories/:id Delete Category
 * @apiName DeleteCategory
 * @apiGroup Category
 * @apiVersion 1.0.0
 *
 * @apiParam {Number} id Category’s unique ID.
 *
 * @apiSuccess {String} message Deletion confirmation message.
 * @apiSuccess {Number} id Deleted category ID.
 *
 * @apiSuccessExample {json} Success Response:
 * HTTP/1.1 200 OK
 * {
 *   "message": "Category deleted successfully",
 *   "id": 3
 * }
 */

class CategoryController extends Controller
{
    public function index()
    {
        $categories = Category::all();
        return response()->json([
            'categories' => $categories,
        ]);
    }

    public function store(CategoryRequest $request)
    {
        $category = Category::create($request->all());

        return response()->json([
            'category' => $category,
        ]);
    }

    public function update(CategoryRequest $request, $id)
	{
		$category = Category::findOrFail($id);
		$category->update($request->all());

		return response()->json([
			'category' => $category,
		]);
	}
    
    public function destroy($id)
    {
        $category = Category::findOrFail($id);
        $category->delete();
        return response()->json([
            'message' => 'Category deleted successfully',
            'id' => $id
        ]);
    }
}
