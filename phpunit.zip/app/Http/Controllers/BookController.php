<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Book;
use App\Http\Requests\BookRequest;
/**
 * @api {get} /books Get All Books
 * @apiName GetBooks
 * @apiGroup Book
 * @apiVersion 1.0.0
 *
 * @apiSuccess {Object[]} books List of books.
 * @apiSuccess {Number} books.id Book ID.
 * @apiSuccess {String} books.title Book title.
 * @apiSuccess {String} [books.author] Book author (optional).
 * @apiSuccess {String} [books.published_at] Publication date (optional).
 * @apiSuccess {String} [books.created_at] Creation timestamp.
 * @apiSuccess {String} [books.updated_at] Last update timestamp.
 *
 * @apiSuccessExample {json} Success Response:
 * HTTP/1.1 200 OK
 * {
 *   "books": [
 *     { "id": 1, "title": "Harry Potter", "author": "J.K. Rowling", "published_at": "1997-06-26" },
 *     { "id": 2, "title": "A Game of Thrones", "author": "George R.R. Martin", "published_at": "1996-08-06" }
 *   ]
 * }
 */

/**
 * @api {post} /books Create Book
 * @apiName CreateBook
 * @apiGroup Book
 * @apiVersion 1.0.0
 *
 * @apiBody {String} title Book title.
 * @apiBody {String} [author] Book author (optional).
 * @apiBody {String} [published_at] Publication date (optional).
 *
 * @apiSuccess {Object} book Created book object.
 * @apiSuccess {Number} book.id Book ID.
 * @apiSuccess {String} book.title Book title.
 * @apiSuccess {String} [book.author] Book author.
 * @apiSuccess {String} [book.published_at] Publication date.
 *
 * @apiSuccessExample {json} Success Response:
 * HTTP/1.1 200 OK
 * {
 *   "book": { "id": 3, "title": "The Hobbit", "author": "J.R.R. Tolkien", "published_at": "1937-09-21" }
 * }
 */

/**
 * @api {put} /books/:id Update Book
 * @apiName UpdateBook
 * @apiGroup Book
 * @apiVersion 1.0.0
 *
 * @apiParam {Number} id Book’s unique ID.
 * @apiBody {String} [title] Book title.
 * @apiBody {String} [author] Book author.
 * @apiBody {String} [published_at] Publication date.
 *
 * @apiSuccess {Object} book Updated book object.
 * @apiSuccess {Number} book.id Book ID.
 * @apiSuccess {String} book.title Book title.
 * @apiSuccess {String} [book.author] Book author.
 * @apiSuccess {String} [book.published_at] Publication date.
 *
 * @apiSuccessExample {json} Success Response:
 * HTTP/1.1 200 OK
 * {
 *   "book": { "id": 3, "title": "The Hobbit: Revised", "author": "J.R.R. Tolkien", "published_at": "1937-09-21" }
 * }
 */

/**
 * @api {delete} /books/:id Delete Book
 * @apiName DeleteBook
 * @apiGroup Book
 * @apiVersion 1.0.0
 *
 * @apiParam {Number} id Book’s unique ID.
 *
 * @apiSuccess {String} message Deletion confirmation message.
 * @apiSuccess {Number} id Deleted book ID.
 *
 * @apiSuccessExample {json} Success Response:
 * HTTP/1.1 200 OK
 * {
 *   "message": "Book deleted successfully",
 *   "id": 3
 * }
 */

class BookController extends Controller
{
    public function index()
    {
        $books = Book::all();
        return response()->json([
            'books' => $books,
        ]);
    }

    public function store(BookRequest $request)
    {
        $book = Book::create($request->all());

        return response()->json([
            'book' => $book,
        ]);
    }

    public function update(BookRequest $request, $id)
	{
		$book = Book::findOrFail($id);
		$book->update($request->all());

		return response()->json([
			'book' => $book,
		]);
	}
    
    public function destroy($id)
    {
        $book = Book::findOrFail($id);
        $book->delete();
        return response()->json([
            'message' => 'Book deleted successfully',
            'id' => $id
        ]);
    }
}
