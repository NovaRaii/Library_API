<?php

namespace App\Http\Controllers;

use App\Models\Author;
use Illuminate\Http\Request;
use App\Http\Requests\AuthorRequest;
/**
 * @api {get} /authors Get All Authors
 * @apiName GetAuthors
 * @apiGroup Author
 * @apiVersion 1.0.0
 *
 * @apiSuccess {Object[]} authors List of authors.
 * @apiSuccess {Number} authors.id Author ID.
 * @apiSuccess {String} authors.name Author name.
 * @apiSuccess {String} [authors.email] Author email (optional).
 * @apiSuccess {String} [authors.created_at] Creation timestamp.
 * @apiSuccess {String} [authors.updated_at] Last update timestamp.
 *
 * @apiSuccessExample {json} Success Response:
 * HTTP/1.1 200 OK
 * {
 *   "authors": [
 *     { "id": 1, "name": "J.K. Rowling", "email": "jk@hogwarts.com" },
 *     { "id": 2, "name": "George R.R. Martin", "email": "grrm@got.com" }
 *   ]
 * }
 */

/**
 * @api {post} /authors Create Author
 * @apiName CreateAuthor
 * @apiGroup Author
 * @apiVersion 1.0.0
 *
 * @apiBody {String} name Author name.
 * @apiBody {String} [email] Author email (optional).
 *
 * @apiSuccess {Object} author Created author object.
 * @apiSuccess {Number} author.id Author ID.
 * @apiSuccess {String} author.name Author name.
 * @apiSuccess {String} [author.email] Author email.
 *
 * @apiSuccessExample {json} Success Response:
 * HTTP/1.1 200 OK
 * {
 *   "author": { "id": 3, "name": "Tolkien", "email": "tolkien@lotr.com" }
 * }
 */

/**
 * @api {put} /authors/:id Update Author
 * @apiName UpdateAuthor
 * @apiGroup Author
 * @apiVersion 1.0.0
 *
 * @apiParam {Number} id Author’s unique ID.
 * @apiBody {String} [name] Author name.
 * @apiBody {String} [email] Author email.
 *
 * @apiSuccess {Object} author Updated author object.
 * @apiSuccess {Number} author.id Author ID.
 * @apiSuccess {String} author.name Author name.
 * @apiSuccess {String} [author.email] Author email.
 *
 * @apiSuccessExample {json} Success Response:
 * HTTP/1.1 200 OK
 * {
 *   "author": { "id": 3, "name": "J.R.R. Tolkien", "email": "tolkien@middleearth.com" }
 * }
 */

/**
 * @api {delete} /authors/:id Delete Author
 * @apiName DeleteAuthor
 * @apiGroup Author
 * @apiVersion 1.0.0
 *
 * @apiParam {Number} id Author’s unique ID.
 *
 * @apiSuccess {String} message Deletion confirmation message.
 * @apiSuccess {Number} id Deleted author ID.
 *
 * @apiSuccessExample {json} Success Response:
 * HTTP/1.1 200 OK
 * {
 *   "message": "Author deleted successfully",
 *   "id": 3
 * }
 */

class AuthorController extends Controller
{
    public function index()
    {
        $authors = Author::all();
        return response()->json([
            'authors' => $authors,
        ]);
    }

    public function store(AuthorRequest $request)
{
    $author = Author::create($request->validated());

    return response()->json([
        'author' => $author,
    ], 201);
}


    public function update(AuthorRequest $request, $id)
{
    $author = Author::findOrFail($id);
    $author->update($request->validated());

    return response()->json([
        'author' => $author,
    ], 200);
}

    
    public function destroy($id)
    {
        $author = Author::findOrFail($id);
        $author->delete();
        return response()->json([
            'message' => 'Author deleted successfully',
            'id' => $id
        ]);
    }

    public function show($id)
{
    $author = Author::findOrFail($id);

    return response()->json([
        'author' => $author,
    ]);
}

}
